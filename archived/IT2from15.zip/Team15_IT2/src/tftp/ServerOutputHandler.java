package tftp;

public class ServerOutputHandler implements OutputHandler {

	@Override
	public void lowPriorityPrint(Object getsToStringedAndPrinted) {
		
		
	}

	@Override
	public void highPriorityPrint(Object getsToStringedAndPrinted) {
		
	}

}
